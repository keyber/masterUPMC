#! /usr/bin/env python3

python3 ./mrpython/Application.py $*

