
while True:
    x = 1 / 1

