def moyenne_trois_nb(a, b, c):
    """
    Number * Number * Number -> float
    
    retourne la moyenne arithmétique des trois nombres a, b et c.
    """
    
    return (a + b + c) / 3.0   # remarque : division flottante

