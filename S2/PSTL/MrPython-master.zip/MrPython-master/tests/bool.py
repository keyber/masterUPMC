
print(2 == 0)
